<?php 

namespace App\Models;

class Kategori extends Model{
	protected $table = 'kategori';
}