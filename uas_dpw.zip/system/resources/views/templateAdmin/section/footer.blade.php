<footer class="footer text-muted">
	<span class="float-right">Designed and Developed by : Gunawan</span>
    <strong>Copyright &copy; 2020 @if(date('Y') > '2020') - {{date('Y')}} @endif</strong>
    All Rights Reserved by Adminmart.
</footer>