<ul class="list-group list-group-flush p-2">
	<li class="list-group-item bg-dark text-white">BEST SELLING</li>
	<li class="list-group-item">
		<div class="row">
			<div class="col-sm-3">
	  			<img style="width:70px;" src="system/resources/assets/best-selling/iphone-11.jpg" alt="...">
	  		</div>
			<div class="col-sm-9">
	  			<h4>Iphone 11 Max Pro</h4>
	  			<p>Rp. 12.000.000,00 <i class="fas fa-cart-plus float-right"></i></p>
	  		</div>
		</div>
	</li>
  	<li class="list-group-item">
		<div class="row">
  			<div class="col-sm-3">
	  			<img style="width:70px;" src="system/resources/assets/best-selling/iphone-6s.png" alt="...">
	  		</div>
	  		<div class="col-sm-9">
	  			<h4>Iphone 6S</h4>
	  			<p>Rp. 9.500.000,00 <i class="fas fa-cart-plus float-right"></i></p>
	  		</div>
		</div>
  	</li>
	<li class="list-group-item">
		<div class="row">
 			<div class="col-sm-3">
	  			<img style="width:70px;" src="system/resources/assets/best-selling/iphone-7.jfif" alt="...">
	  		</div>
	  		<div class="col-sm-9">
				<h4>Iphone 7</h4>
	  			<p>Rp. 8.500.000,00 <i class="fas fa-cart-plus float-right"></i></p>
	  		</div>
  		</div>
  	</li>
</ul>
<ul class="list-group list-group-flush p-2">
  	<li class="list-group-item bg-dark text-white">Our Services</li>
  	<li class="list-group-item"><i class="fas fa-greater-than mr-2"></i>Mobile</li>
  	<li class="list-group-item"><i class="fas fa-greater-than mr-2"></i>Laptop</li>
  	<li class="list-group-item"><i class="fas fa-greater-than mr-2"></i>Camera</li>
  	<li class="list-group-item"><i class="fas fa-greater-than mr-2"></i>Ipod</li>
 	<li class="list-group-item"><i class="fas fa-greater-than mr-2"></i>Apple</li>
  	<li class="list-group-item"><i class="fas fa-greater-than mr-2"></i>Accessories</li>
</ul>