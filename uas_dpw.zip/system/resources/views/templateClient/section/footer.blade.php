<footer class="main-footer">
        <div class="copyrights">
          <div class="container">
            <div class="row">
              <div class="col-lg-4 text-center-md">
                <p>&copy; 2020. Informatika Politap / Gunawan</p>
              </div>
              <div class="col-lg-8 text-right text-center-md">
                <p>Template design by <a href="#">Gunawan </a></p>
              </div>
            </div>
          </div>
        </div>
      </footer>