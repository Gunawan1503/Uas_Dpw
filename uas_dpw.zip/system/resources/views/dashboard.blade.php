@extends('templateAdmin.base')

@section('content')
	<h3>Ini Halaman Dashboard</h3>
@endsection