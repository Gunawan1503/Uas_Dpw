@extends('templateAdmin.base')

@section('content')
	<h3>Ini Halaman Kategori</h3>
@endsection